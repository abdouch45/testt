const feedback=(props)=>{
    return (
        <div>
            <h3>{props.data.name}</h3>
            <h3>{props.data.role}</h3>
            <p>{props.data.text}</p>
        </div>
    );
    }
    export default feedback;