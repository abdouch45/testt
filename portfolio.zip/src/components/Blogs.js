const blogs=(props)=>{
return (
    <div>
        <img src={props.data.path} alt="blog img" />
        <h3>{props.data.author}</h3>
        <h3>{props.data.title}</h3>
        <p>{props.data.text}</p>
    </div>
);
}
export default blogs;