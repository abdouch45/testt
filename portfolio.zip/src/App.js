import ContactForm from './components/contactForm.js'
import NavBar from './components/navBar.js'
import Blogs from './components/Blogs.js'
import Feedback from './components/feedBack.js'


const feedbacks=[{name:"Anis Abed",role:"colleague",text:"serious the best coleague i had"},
{name:"client1",role:"client",text:"good job"},
{name:"client2",role:"client",text:"good job delivred in time"}]
const blogs=[{author:"Anis Abed",title:"blog1",text:"blog number 1 for testing",path:"/blog1.jfif"},
{author:"uknown",title:"blog2",text:"blog number 2 for testing",path:"/blog1.jfif"}]

function App() {
  return (
    <div className="App">
      <NavBar/>
      <div id='Home'>
          <p>welcome to my portfolio my name is  Abelmoudjib Chihoub 21 years old</p>
      </div>
      <div id='showcase'>
          <p>showcase</p>
      </div>
      <div id='skills'>
          <p>Skills</p>
      </div>
      <div id='contactInfo'>
          <p>showcase</p>
          <ContactForm/>
      </div>
       <div id='blogs'>
       {blogs.map((blog)=> <Blogs data={blog}></Blogs>) }
       </div>
      <div id='feedback'>
      {feedbacks.map((feedback)=><Feedback data={feedback}/>) }
      </div>


    </div>
  );
}

export default App;